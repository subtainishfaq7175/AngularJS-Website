'use strict';

describe('gameApp module', function() {

  beforeEach(module('gameApp'));

  describe('newspost controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view1Ctrl = $controller('NewspostCtrl');
      expect(view1Ctrl).toBeDefined();
    }));

  });
});