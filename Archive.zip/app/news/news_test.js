'use strict';

describe('gameApp module', function() {

  beforeEach(module('gameApp'));

  describe('news controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view1Ctrl = $controller('NewsCtrl');
      expect(view1Ctrl).toBeDefined();
    }));

  });
});